import Vue from 'vue'
import Router from 'vue-router'
import JuryPage from '@/components/JuryPage'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/jurypage',
      name: 'JuryPage',
      component: JuryPage
    },
     {
      path: '*',
      name: 'JuryPage',
      component: JuryPage
    }
  ]
})
